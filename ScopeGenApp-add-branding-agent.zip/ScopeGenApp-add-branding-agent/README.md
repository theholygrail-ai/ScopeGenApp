# ScopeGenApp
This application is intended to automate the SOW process For eComplete 
